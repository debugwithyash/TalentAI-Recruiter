import { useEffect, useRef, useState, type ReactNode, type MouseEvent } from "react";
import { motion } from "framer-motion";

/* ---------- Aurora + grid + particles background ---------- */
export function AuroraBackdrop({ withGrid = true, withParticles = true }: { withGrid?: boolean; withParticles?: boolean }) {
  return (
    <div aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden">
      <div className="aurora-bg" />
      {withGrid && <div className="absolute inset-0 grid-lines" />}
      <div className="absolute inset-0 noise" />
      {withParticles && <Particles count={28} />}
    </div>
  );
}

function Particles({ count = 24 }: { count?: number }) {
  // Deterministic so SSR matches client
  const items = Array.from({ length: count }, (_, i) => {
    const seed = (i * 9301 + 49297) % 233280;
    const r = seed / 233280;
    const r2 = ((i * 7793 + 1301) % 9973) / 9973;
    const r3 = ((i * 3137 + 521) % 7919) / 7919;
    return {
      left: `${(r * 100).toFixed(2)}%`,
      size: 2 + Math.round(r2 * 4),
      delay: -(r3 * 18).toFixed(2) + "s",
      duration: 14 + Math.round(r2 * 16) + "s",
      dx: `${Math.round((r - 0.5) * 120)}px`,
      hue: r2 > 0.5 ? 280 : 310,
      opacity: 0.4 + r3 * 0.5,
    };
  });
  return (
    <div className="absolute inset-0">
      {items.map((p, i) => (
        <span
          key={i}
          className="absolute bottom-[-10%] rounded-full"
          style={{
            left: p.left,
            width: p.size,
            height: p.size,
            background: `radial-gradient(circle, oklch(0.85 0.18 ${p.hue} / ${p.opacity}) 0%, transparent 70%)`,
            boxShadow: `0 0 ${p.size * 4}px oklch(0.75 0.2 ${p.hue} / 0.7)`,
            animation: `particle-rise ${p.duration} linear infinite`,
            animationDelay: p.delay,
            // @ts-expect-error css var
            "--dx": p.dx,
          }}
        />
      ))}
    </div>
  );
}

/* ---------- Mouse-following radial glow ---------- */
export function MouseGlow({ children, className = "" }: { children: ReactNode; className?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const [pos, setPos] = useState({ x: 50, y: 30, active: false });

  const handle = (e: MouseEvent<HTMLDivElement>) => {
    const el = ref.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    setPos({ x: ((e.clientX - r.left) / r.width) * 100, y: ((e.clientY - r.top) / r.height) * 100, active: true });
  };

  return (
    <div
      ref={ref}
      onMouseMove={handle}
      onMouseLeave={() => setPos((p) => ({ ...p, active: false }))}
      className={`relative ${className}`}
    >
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 transition-opacity duration-500"
        style={{
          opacity: pos.active ? 1 : 0,
          background: `radial-gradient(600px circle at ${pos.x}% ${pos.y}%, oklch(0.72 0.22 285 / 0.18), transparent 45%)`,
        }}
      />
      {children}
    </div>
  );
}

/* ---------- Magnetic button wrapper ---------- */
export function Magnetic({ children, strength = 18 }: { children: ReactNode; strength?: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const [t, setT] = useState({ x: 0, y: 0 });
  const handle = (e: MouseEvent<HTMLDivElement>) => {
    const el = ref.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    const dx = (e.clientX - (r.left + r.width / 2)) / r.width;
    const dy = (e.clientY - (r.top + r.height / 2)) / r.height;
    setT({ x: dx * strength, y: dy * strength });
  };
  return (
    <div
      ref={ref}
      onMouseMove={handle}
      onMouseLeave={() => setT({ x: 0, y: 0 })}
      className="inline-block will-change-transform transition-transform duration-300"
      style={{ transform: `translate3d(${t.x}px, ${t.y}px, 0)` }}
    >
      {children}
    </div>
  );
}

/* ---------- Animated counter ---------- */
export function Counter({ to, decimals = 0, suffix = "", duration = 1.4 }: { to: number; decimals?: number; suffix?: string; duration?: number }) {
  const [v, setV] = useState(0);
  useEffect(() => {
    let raf = 0;
    const start = performance.now();
    const tick = (now: number) => {
      const p = Math.min(1, (now - start) / (duration * 1000));
      const eased = 1 - Math.pow(1 - p, 3);
      setV(to * eased);
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [to, duration]);
  return <span>{v.toFixed(decimals)}{suffix}</span>;
}

/* ---------- Scroll reveal ---------- */
export function Reveal({ children, delay = 0, y = 24 }: { children: ReactNode; delay?: number; y?: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-80px" }}
      transition={{ duration: 0.7, delay, ease: [0.22, 1, 0.36, 1] }}
    >
      {children}
    </motion.div>
  );
}
