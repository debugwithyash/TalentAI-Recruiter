import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Check, Loader2, Sparkles } from "lucide-react";
import { AI_PIPELINE_STAGES } from "@/services/api";

type Props = {
  open: boolean;
  onComplete?: () => void;
  onClose?: () => void;
};

/**
 * Animated AI pipeline modal — visualizes the ranking stages.
 * Steps through each stage on a timer; calls onComplete when done.
 */
export function AIPipelineModal({ open, onComplete, onClose }: Props) {
  const [step, setStep] = useState(0);

  useEffect(() => {
    if (!open) {
      setStep(0);
      return;
    }
    if (step >= AI_PIPELINE_STAGES.length - 1) {
      const t = setTimeout(() => onComplete?.(), 600);
      return () => clearTimeout(t);
    }
    const t = setTimeout(() => setStep((s) => s + 1), 520);
    return () => clearTimeout(t);
  }, [open, step, onComplete]);

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 grid place-items-center bg-background/70 backdrop-blur-md p-4"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.95, y: 10, opacity: 0 }}
            animate={{ scale: 1, y: 0, opacity: 1 }}
            exit={{ scale: 0.95, opacity: 0 }}
            onClick={(e) => e.stopPropagation()}
            className="glass rounded-3xl p-7 w-full max-w-md shadow-glow"
          >
            <div className="flex items-center gap-3 mb-5">
              <div className="size-11 rounded-2xl gradient-brand grid place-items-center shadow-glow">
                <Sparkles className="size-5 text-white animate-pulse" />
              </div>
              <div>
                <div className="font-semibold">AI Ranking Engine</div>
                <div className="text-xs text-muted-foreground">
                  Running semantic + LLM pipeline...
                </div>
              </div>
            </div>

            <div className="space-y-2.5">
              {AI_PIPELINE_STAGES.map((stage, i) => {
                const done = i < step;
                const active = i === step;
                return (
                  <motion.div
                    key={stage}
                    initial={{ opacity: 0, x: -8 }}
                    animate={{ opacity: i <= step ? 1 : 0.35, x: 0 }}
                    className={`flex items-center gap-3 rounded-xl px-3 py-2 text-sm transition ${
                      active ? "bg-primary/10 border border-primary/30" : ""
                    }`}
                  >
                    <div
                      className={`size-6 rounded-full grid place-items-center text-xs ${
                        done
                          ? "gradient-brand text-white"
                          : active
                            ? "bg-primary/20 text-primary"
                            : "bg-muted text-muted-foreground"
                      }`}
                    >
                      {done ? (
                        <Check className="size-3.5" />
                      ) : active ? (
                        <Loader2 className="size-3.5 animate-spin" />
                      ) : (
                        i + 1
                      )}
                    </div>
                    <span className={active ? "font-medium" : ""}>{stage}</span>
                  </motion.div>
                );
              })}
            </div>

            <div className="mt-5 h-1.5 rounded-full bg-muted overflow-hidden">
              <motion.div
                className="h-full gradient-brand"
                animate={{ width: `${((step + 1) / AI_PIPELINE_STAGES.length) * 100}%` }}
                transition={{ duration: 0.4 }}
              />
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
