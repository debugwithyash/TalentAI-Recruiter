import { Link, useRouterState } from "@tanstack/react-router";
import {
  LayoutDashboard, FileText, Users, Sparkles, BarChart3, Network,
  Settings, Brain, Moon, Sun, Bell, Search,
} from "lucide-react";
import { type ReactNode } from "react";
import { useTheme } from "@/lib/theme";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Toaster } from "@/components/ui/sonner";

const navItems = [
  { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { to: "/jobs", label: "Job Description", icon: FileText },
  { to: "/candidates", label: "Candidates", icon: Users },
  { to: "/ranking", label: "AI Ranking", icon: Sparkles },
  { to: "/architecture", label: "AI Architecture", icon: Network },
  { to: "/analytics", label: "Analytics", icon: BarChart3 },
];

export function AppLayout({ children }: { children: ReactNode }) {
  const { theme, toggle } = useTheme();
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  return (
    <div className="min-h-screen flex w-full bg-background text-foreground">
      <aside className="hidden lg:flex w-64 flex-col border-r border-border bg-sidebar/80 backdrop-blur-xl">
        <Link to="/" className="flex items-center gap-2 px-6 py-5 border-b border-sidebar-border">
          <div className="size-9 rounded-xl gradient-brand grid place-items-center shadow-glow">
            <Brain className="size-5 text-white" />
          </div>
          <div>
            <div className="font-bold tracking-tight">TalentAI</div>
            <div className="text-[11px] text-muted-foreground -mt-0.5">Recruiter Suite</div>
          </div>
        </Link>

        <nav className="flex-1 p-3 space-y-1">
          {navItems.map((item) => {
            const active = pathname.startsWith(item.to);
            return (
              <Link
                key={item.to}
                to={item.to}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${
                  active
                    ? "gradient-brand text-white shadow-glow"
                    : "text-sidebar-foreground hover:bg-sidebar-accent"
                }`}
              >
                <item.icon className="size-4" />
                {item.label}
              </Link>
            );
          })}
        </nav>

        <div className="p-3 border-t border-sidebar-border">
          <Link
            to="/settings"
            className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm hover:bg-sidebar-accent text-sidebar-foreground"
          >
            <Settings className="size-4" />
            Settings
          </Link>
        </div>
      </aside>

      <div className="flex-1 flex flex-col min-w-0">
        <header className="sticky top-0 z-30 h-16 border-b border-border bg-background/70 backdrop-blur-xl">
          <div className="h-full flex items-center gap-3 px-4 lg:px-8">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
              <Input placeholder="Search candidates, jobs, skills..." className="pl-9 bg-muted/40 border-transparent" />
            </div>
            <div className="ml-auto flex items-center gap-2">
              <Button variant="ghost" size="icon" onClick={toggle} aria-label="Toggle theme">
                {theme === "dark" ? <Sun className="size-4" /> : <Moon className="size-4" />}
              </Button>
              <Button variant="ghost" size="icon">
                <Bell className="size-4" />
              </Button>
              <Avatar className="size-9 ring-2 ring-primary/30">
                <AvatarFallback className="gradient-brand text-white font-semibold">RA</AvatarFallback>
              </Avatar>
            </div>
          </div>
        </header>

        <main className="flex-1 p-4 lg:p-8">{children}</main>
      </div>
      <Toaster richColors position="top-right" />
    </div>
  );
}
