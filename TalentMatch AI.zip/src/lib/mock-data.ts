export type Candidate = {
  id: string;
  name: string;
  title: string;
  avatar: string;
  experience: number;
  skills: string[];
  education: string;
  github: string;
  linkedin: string;
  location: string;
  availability: "Available" | "Open" | "Not looking";
  workMode: "Remote" | "Hybrid" | "Onsite";
  status: "New" | "Shortlisted" | "Interviewing" | "Rejected";
  bookmarked?: boolean;
  confidence: number;
  scores: {
    semantic: number;
    skill: number;
    experience: number;
    behavioral: number;
    activity: number;
  };
  aiSummary: string;
  strengths: string[];
  weaknesses: string[];
  recommendation: "Strong Hire" | "Hire" | "Maybe" | "Pass";
  reasons: { selected: string[]; missing: string[] };
  projects: { name: string; description: string }[];
  certifications: string[];
  timeline: { date: string; event: string }[];
};

const skillsPool = [
  "Python", "TypeScript", "React", "Node.js", "FastAPI", "PyTorch",
  "NLP", "LangChain", "AWS", "Docker", "Kubernetes", "PostgreSQL",
  "GraphQL", "Tailwind", "Next.js", "Vector DB", "RAG", "LLMs",
];

const names = [
  "Aisha Khan", "Marcus Chen", "Priya Patel", "Daniel Okafor",
  "Sofia Rodriguez", "Ethan Wright", "Hannah Lee", "Noah Bennett",
  "Maya Singh", "Lucas Schmidt", "Zara Ahmed", "Olivia Park",
];

const titles = [
  "Senior ML Engineer", "Full-Stack Developer", "AI Research Engineer",
  "Backend Engineer", "Data Scientist", "Platform Engineer",
];

function rand(min: number, max: number) {
  return Math.round(min + Math.random() * (max - min));
}

function pickN<T>(arr: T[], n: number): T[] {
  return [...arr].sort(() => Math.random() - 0.5).slice(0, n);
}

const availabilities: Candidate["availability"][] = ["Available", "Open", "Not looking"];
const modes: Candidate["workMode"][] = ["Remote", "Hybrid", "Onsite"];
const recs: Candidate["recommendation"][] = ["Strong Hire", "Hire", "Maybe", "Pass"];

export const candidates: Candidate[] = names.map((name, i) => {
  const semantic = rand(70, 98);
  const skill = rand(60, 99);
  const experience = rand(55, 95);
  const behavioral = rand(60, 95);
  const activity = rand(50, 99);
  const confidence = rand(78, 98);
  return {
    id: `c${i + 1}`,
    name,
    title: titles[i % titles.length],
    avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(name)}`,
    experience: rand(2, 12),
    skills: pickN(skillsPool, rand(4, 7)),
    education: ["MS Computer Science", "BS Software Engineering", "PhD AI"][i % 3],
    github: `github.com/${name.toLowerCase().replace(" ", "")}`,
    linkedin: `linkedin.com/in/${name.toLowerCase().replace(" ", "")}`,
    location: ["San Francisco", "Berlin", "Bangalore", "London", "Toronto"][i % 5],
    availability: availabilities[i % 3],
    workMode: modes[i % 3],
    status: (["New", "Shortlisted", "Interviewing", "Rejected"] as const)[i % 4],
    bookmarked: i % 4 === 0,
    confidence,
    scores: { semantic, skill, experience, behavioral, activity },
    aiSummary:
      "Strong semantic alignment with the role, backed by production LLM systems and a measurable track record shipping ranked search at scale.",
    strengths: [
      "Production LLM and RAG experience",
      "Deep Python + PyTorch expertise",
      "Owned end-to-end MLOps pipelines",
      "Active open-source contributor",
    ],
    weaknesses: [
      "Limited large-team leadership",
      "No prior fintech domain context",
    ],
    recommendation: recs[i % 4],
    reasons: {
      selected: [
        "Strong Python and NLP background",
        "Relevant production LLM projects",
        "Active open-source contributor",
        "Experience matches seniority level",
        "Leadership experience on shipped products",
      ],
      missing: i % 2 === 0
        ? ["Missing AWS certification", "Limited Kubernetes experience", "No healthcare domain experience"]
        : ["No prior fintech domain", "Limited team-leadership history"],
    },
    projects: [
      { name: "Semantic Search Engine", description: "Built a RAG pipeline over 1M docs using pgvector." },
      { name: "Resume Parser", description: "NER pipeline extracting structured data from resumes." },
    ],
    certifications: ["AWS ML Specialty", "TensorFlow Developer"],
    timeline: [
      { date: "2024", event: "Senior ML Engineer @ Acme" },
      { date: "2021", event: "ML Engineer @ DataCo" },
      { date: "2019", event: "MS Computer Science" },
    ],
  };
});

export function finalScore(c: Candidate) {
  const s = c.scores;
  return Math.round(
    s.semantic * 0.4 + s.skill * 0.25 + s.experience * 0.15 +
    s.behavioral * 0.1 + s.activity * 0.1
  );
}

export const rankedCandidates = [...candidates]
  .map((c) => ({ ...c, final: finalScore(c) }))
  .sort((a, b) => b.final - a.final);

export const extractedJD = {
  requiredSkills: ["Python", "NLP", "LLMs", "PyTorch"],
  preferredSkills: ["Vector DB", "FastAPI", "LangChain", "AWS"],
  experience: "5+ years in ML/AI engineering",
  education: "BS/MS in Computer Science or related field",
  certifications: ["AWS ML Specialty (preferred)", "TensorFlow Developer (nice-to-have)"],
  responsibilities: [
    "Design and ship semantic search and ranking systems",
    "Fine-tune embedding models for domain data",
    "Own MLOps from training to deployment",
    "Mentor engineers on best practices",
  ],
  seniority: "Senior (L5 / IC4)",
  industry: "AI Platform / Enterprise SaaS",
  softSkills: ["Cross-functional communication", "Ownership", "Mentorship", "Bias for action"],
};

// Legacy alias for any old imports
export const extractedJDLegacy = extractedJD;

export const topSkillsData = [
  { skill: "Python", count: 42 },
  { skill: "React", count: 38 },
  { skill: "TypeScript", count: 35 },
  { skill: "LLMs", count: 28 },
  { skill: "AWS", count: 24 },
  { skill: "Docker", count: 21 },
];

export const experienceData = [
  { range: "0-2", count: 8 },
  { range: "3-5", count: 22 },
  { range: "6-9", count: 18 },
  { range: "10+", count: 9 },
];

export const funnelData = [
  { stage: "Applied", value: 320 },
  { stage: "Screened", value: 180 },
  { stage: "Matched", value: 95 },
  { stage: "Interview", value: 42 },
  { stage: "Offer", value: 12 },
];

export const educationBreakdown = [
  { name: "BS", value: 42 },
  { name: "MS", value: 38 },
  { name: "PhD", value: 12 },
  { name: "Bootcamp", value: 8 },
];

export const rankingDistribution = [
  { bucket: "90-100", count: 6 },
  { bucket: "80-89", count: 14 },
  { bucket: "70-79", count: 22 },
  { bucket: "60-69", count: 11 },
  { bucket: "<60", count: 4 },
];

export const hiringTrends = Array.from({ length: 6 }, (_, i) => ({
  month: ["Jan", "Feb", "Mar", "Apr", "May", "Jun"][i],
  applied: rand(120, 280),
  hired: rand(4, 18),
}));

export const aiAccuracyTrend = Array.from({ length: 8 }, (_, i) => ({
  week: `W${i + 1}`,
  accuracy: Math.min(98, 82 + i + Math.round(Math.random() * 3)),
}));
