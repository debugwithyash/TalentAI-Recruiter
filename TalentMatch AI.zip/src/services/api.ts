/**
 * Mock AI Backend Service Layer
 * ------------------------------------------------------------------
 * Placeholder API ready to be swapped for a real FastAPI backend.
 *
 * Suggested FastAPI routes:
 *   POST /api/jd/analyze        -> JDAnalysis
 *   POST /api/jd/upload         -> { jobId }
 *   POST /api/candidates/rank   -> RankedCandidate[]
 *   GET  /api/candidates        -> Candidate[]
 *   GET  /api/candidates/:id    -> Candidate
 *   POST /api/export/:format    -> file blob
 *
 * AI Stack target:
 *   - Sentence Transformers (all-MiniLM, E5)
 *   - FAISS / ChromaDB vector store
 *   - OpenAI / Gemini / Qwen for re-ranking + explanations
 */

import {
  candidates,
  extractedJD,
  rankedCandidates,
  type Candidate,
} from "@/lib/mock-data";

export type JDAnalysis = typeof extractedJD;

const delay = (ms: number) => new Promise((r) => setTimeout(r, ms));

export const api = {
  async analyzeJD(_text: string): Promise<JDAnalysis> {
    await delay(900);
    return extractedJD;
  },

  async uploadJD(file: File): Promise<{ jobId: string; filename: string }> {
    await delay(700);
    return { jobId: `job_${Date.now()}`, filename: file.name };
  },

  async listCandidates(): Promise<Candidate[]> {
    await delay(300);
    return candidates;
  },

  async getCandidate(id: string): Promise<Candidate | undefined> {
    await delay(200);
    return candidates.find((c) => c.id === id);
  },

  async rankCandidates(_jobId?: string) {
    await delay(400);
    return rankedCandidates;
  },

  async exportRanking(format: "csv" | "excel" | "pdf"): Promise<Blob> {
    await delay(500);
    return new Blob([`ranking.${format}`], { type: "text/plain" });
  },
};

/** Stages the recruiter sees while AI ranking runs. */
export const AI_PIPELINE_STAGES = [
  "Reading Job Description",
  "Generating Embeddings",
  "Searching Vector Database",
  "Semantic Matching",
  "Scoring Skills",
  "Evaluating Experience",
  "LLM Re-ranking",
  "Generating Explainable Results",
  "Completed",
] as const;

export type PipelineStage = (typeof AI_PIPELINE_STAGES)[number];
