import { createFileRoute } from "@tanstack/react-router";
import { AppLayout } from "@/components/AppLayout";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { useTheme } from "@/lib/theme";

export const Route = createFileRoute("/settings")({
  head: () => ({ meta: [{ title: "Settings — TalentAI" }] }),
  component: Settings,
});

function Settings() {
  const { theme, toggle } = useTheme();
  return (
    <AppLayout>
      <div className="space-y-6 max-w-2xl">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Settings</h1>
          <p className="text-muted-foreground mt-1">Manage your preferences.</p>
        </div>
        <div className="glass rounded-2xl p-6 space-y-5">
          <div className="flex items-center justify-between">
            <div>
              <Label className="text-base">Dark mode</Label>
              <p className="text-sm text-muted-foreground">Switch between light and dark theme.</p>
            </div>
            <Switch checked={theme === "dark"} onCheckedChange={toggle} />
          </div>
          <div className="flex items-center justify-between">
            <div>
              <Label className="text-base">Email notifications</Label>
              <p className="text-sm text-muted-foreground">Get notified about new top matches.</p>
            </div>
            <Switch defaultChecked />
          </div>
          <div className="flex items-center justify-between">
            <div>
              <Label className="text-base">AI explanations</Label>
              <p className="text-sm text-muted-foreground">Show reasons selected & gaps for each candidate.</p>
            </div>
            <Switch defaultChecked />
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
