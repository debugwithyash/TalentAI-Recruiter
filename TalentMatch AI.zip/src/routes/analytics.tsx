import { createFileRoute } from "@tanstack/react-router";
import { AppLayout } from "@/components/AppLayout";
import {
  ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid,
  PieChart, Pie, Cell, LineChart, Line, Legend,
} from "recharts";
import {
  topSkillsData, experienceData, funnelData, rankedCandidates,
  educationBreakdown, rankingDistribution, hiringTrends, aiAccuracyTrend,
} from "@/lib/mock-data";

export const Route = createFileRoute("/analytics")({
  head: () => ({ meta: [{ title: "Analytics — TalentAI" }] }),
  component: Analytics,
});

const COLORS = ["var(--chart-1)", "var(--chart-2)", "var(--chart-3)", "var(--chart-4)", "var(--chart-5)"];

function Card({ title, subtitle, children, className = "" }: { title: string; subtitle?: string; children: React.ReactNode; className?: string }) {
  return (
    <div className={`glass rounded-2xl p-6 ${className}`}>
      <div className="mb-4">
        <h3 className="font-semibold">{title}</h3>
        {subtitle && <p className="text-xs text-muted-foreground">{subtitle}</p>}
      </div>
      <div className="h-64">{children}</div>
    </div>
  );
}

const tooltipStyle = { background: "var(--popover)", border: "1px solid var(--border)", borderRadius: 12 };

function Analytics() {
  const avgScore = Math.round(rankedCandidates.reduce((sum, c) => sum + c.final, 0) / rankedCandidates.length);

  return (
    <AppLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Analytics</h1>
          <p className="text-muted-foreground mt-1">Insights across your hiring pipeline.</p>
        </div>

        {/* Headline metrics */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            { label: "Avg Match Score", value: avgScore },
            { label: "AI Accuracy", value: "94.2%" },
            { label: "Hired this Q", value: 42 },
            { label: "Open Roles", value: 27 },
          ].map((s) => (
            <div key={s.label} className="glass rounded-2xl p-5">
              <div className="text-xs uppercase tracking-wider text-muted-foreground">{s.label}</div>
              <div className="mt-1 text-3xl font-bold text-gradient-brand">{s.value}</div>
            </div>
          ))}
        </div>

        <div className="grid lg:grid-cols-2 gap-4">
          <Card title="Top skills" subtitle="Most common in your pool">
            <ResponsiveContainer>
              <BarChart data={topSkillsData}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="skill" stroke="var(--muted-foreground)" fontSize={11} />
                <YAxis stroke="var(--muted-foreground)" fontSize={11} />
                <Tooltip contentStyle={tooltipStyle} />
                <Bar dataKey="count" fill="var(--brand)" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </Card>

          <Card title="Education breakdown" subtitle="Degree distribution">
            <ResponsiveContainer>
              <PieChart>
                <Pie data={educationBreakdown} dataKey="value" nameKey="name" innerRadius={50} outerRadius={90} paddingAngle={3}>
                  {educationBreakdown.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Pie>
                <Tooltip contentStyle={tooltipStyle} />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </Card>

          <Card title="Experience distribution">
            <ResponsiveContainer>
              <BarChart data={experienceData}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="range" stroke="var(--muted-foreground)" fontSize={11} />
                <YAxis stroke="var(--muted-foreground)" fontSize={11} />
                <Tooltip contentStyle={tooltipStyle} />
                <Bar dataKey="count" fill="var(--accent-purple)" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </Card>

          <Card title="Hiring funnel">
            <ResponsiveContainer>
              <BarChart data={funnelData} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis type="number" stroke="var(--muted-foreground)" fontSize={11} />
                <YAxis type="category" dataKey="stage" stroke="var(--muted-foreground)" fontSize={11} width={70} />
                <Tooltip contentStyle={tooltipStyle} />
                <Bar dataKey="value" fill="var(--brand)" radius={[0, 8, 8, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </Card>

          <Card title="Ranking distribution" subtitle="AI score buckets">
            <ResponsiveContainer>
              <BarChart data={rankingDistribution}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="bucket" stroke="var(--muted-foreground)" fontSize={11} />
                <YAxis stroke="var(--muted-foreground)" fontSize={11} />
                <Tooltip contentStyle={tooltipStyle} />
                <Bar dataKey="count" fill="var(--chart-2)" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </Card>

          <Card title="Hiring trends" subtitle="Applied vs hired by month">
            <ResponsiveContainer>
              <LineChart data={hiringTrends}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="month" stroke="var(--muted-foreground)" fontSize={11} />
                <YAxis stroke="var(--muted-foreground)" fontSize={11} />
                <Tooltip contentStyle={tooltipStyle} />
                <Legend />
                <Line type="monotone" dataKey="applied" stroke="var(--brand)" strokeWidth={2} dot={{ r: 3 }} />
                <Line type="monotone" dataKey="hired" stroke="var(--accent-purple)" strokeWidth={2} dot={{ r: 3 }} />
              </LineChart>
            </ResponsiveContainer>
          </Card>

          <Card title="AI accuracy" subtitle="Re-ranker quality over time" className="lg:col-span-2">
            <ResponsiveContainer>
              <LineChart data={aiAccuracyTrend}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="week" stroke="var(--muted-foreground)" fontSize={11} />
                <YAxis stroke="var(--muted-foreground)" fontSize={11} domain={[60, 100]} />
                <Tooltip contentStyle={tooltipStyle} />
                <Line type="monotone" dataKey="accuracy" stroke="var(--brand)" strokeWidth={3} dot={{ r: 4, fill: "var(--brand)" }} />
              </LineChart>
            </ResponsiveContainer>
          </Card>
        </div>

        <div className="glass rounded-2xl p-6">
          <h3 className="font-semibold mb-4">Recent rankings</h3>
          <div className="space-y-2">
            {rankedCandidates.slice(0, 6).map((c) => (
              <div key={c.id} className="flex items-center gap-3 py-2 border-b border-border last:border-0">
                <div className="size-8 rounded-full gradient-brand grid place-items-center text-white text-xs font-semibold">
                  {c.name.split(" ").map((n) => n[0]).join("")}
                </div>
                <div className="flex-1 text-sm">{c.name}</div>
                <div className="text-xs text-muted-foreground">{c.title}</div>
                <div className="font-bold text-sm w-10 text-right">{c.final}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
