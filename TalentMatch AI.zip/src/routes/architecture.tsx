import { createFileRoute } from "@tanstack/react-router";
import { motion } from "framer-motion";
import {
  FileText, ScanSearch, Sparkles, Database, Search, Layers,
  Brain, BadgeCheck, Trophy,
} from "lucide-react";
import { AppLayout } from "@/components/AppLayout";

export const Route = createFileRoute("/architecture")({
  head: () => ({ meta: [{ title: "AI Architecture — TalentAI" }] }),
  component: ArchitecturePage,
});

const steps = [
  { icon: FileText, title: "Job Description", desc: "Recruiter pastes or uploads the JD (PDF, DOCX, TXT)." },
  { icon: ScanSearch, title: "Requirement Extraction", desc: "LLM extracts skills, experience, responsibilities, seniority." },
  { icon: Sparkles, title: "Sentence Transformer", desc: "all-MiniLM / E5 encoder produces dense semantic vectors." },
  { icon: Database, title: "Vector Embeddings", desc: "Candidate profiles embedded once, cached in vector store." },
  { icon: Search, title: "FAISS Vector Search", desc: "Top-K nearest neighbours retrieved by cosine similarity." },
  { icon: Layers, title: "Top Candidates", desc: "Coarse pool of 50–100 semantically relevant matches." },
  { icon: Brain, title: "LLM Re-ranking", desc: "Cross-encoder + GPT-4 class model re-ranks with full context." },
  { icon: BadgeCheck, title: "Explainable AI", desc: "Model generates 'why selected' and 'why not perfect' rationale." },
  { icon: Trophy, title: "Final Ranking", desc: "Weighted score surfaces the best candidates for the role." },
];

const weights = [
  { label: "Semantic Similarity", pct: 40, color: "from-blue-500 to-cyan-400" },
  { label: "Skill Match", pct: 25, color: "from-purple-500 to-fuchsia-400" },
  { label: "Experience", pct: 15, color: "from-emerald-500 to-teal-400" },
  { label: "Behavioral Signals", pct: 10, color: "from-amber-500 to-orange-400" },
  { label: "Platform Activity", pct: 10, color: "from-rose-500 to-pink-400" },
];

function ArchitecturePage() {
  return (
    <AppLayout>
      <div className="space-y-8 max-w-6xl">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">AI Architecture</h1>
          <p className="text-muted-foreground mt-1">
            End-to-end semantic recruitment pipeline — from raw JD to explainable ranking.
          </p>
        </div>

        {/* Pipeline */}
        <div className="grid md:grid-cols-3 gap-4">
          {steps.map((s, i) => (
            <motion.div
              key={s.title}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ delay: i * 0.05 }}
              className="glass rounded-2xl p-5 relative overflow-hidden group hover:shadow-glow transition-shadow"
            >
              <div className="absolute top-3 right-4 text-[10px] font-mono text-muted-foreground">
                {String(i + 1).padStart(2, "0")}
              </div>
              <div className="size-10 rounded-xl gradient-brand grid place-items-center shadow-glow mb-3">
                <s.icon className="size-5 text-white" />
              </div>
              <div className="font-semibold">{s.title}</div>
              <div className="text-xs text-muted-foreground mt-1 leading-relaxed">{s.desc}</div>
            </motion.div>
          ))}
        </div>

        {/* Ranking formula */}
        <div className="glass rounded-2xl p-6">
          <div className="flex items-center gap-2 mb-4">
            <div className="size-9 rounded-lg gradient-brand grid place-items-center">
              <Trophy className="size-4 text-white" />
            </div>
            <div>
              <h2 className="font-semibold">Ranking Formula</h2>
              <p className="text-xs text-muted-foreground">Final Score = weighted blend of five signals</p>
            </div>
          </div>

          <div className="space-y-3">
            {weights.map((w, i) => (
              <div key={w.label}>
                <div className="flex justify-between text-sm mb-1.5">
                  <span className="font-medium">{w.label}</span>
                  <span className="font-mono text-muted-foreground">{w.pct}%</span>
                </div>
                <div className="h-2 rounded-full bg-muted overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    whileInView={{ width: `${w.pct}%` }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.9, delay: i * 0.1 }}
                    className={`h-full bg-gradient-to-r ${w.color}`}
                  />
                </div>
              </div>
            ))}
          </div>

          <div className="mt-5 rounded-xl bg-background/50 border border-border p-4 font-mono text-xs sm:text-sm text-center">
            <span className="text-muted-foreground">Final Score =</span>{" "}
            <span className="text-gradient-brand font-bold">
              0.40·sem + 0.25·skill + 0.15·exp + 0.10·behavior + 0.10·activity
            </span>
          </div>
        </div>

        {/* Stack */}
        <div className="grid md:grid-cols-3 gap-4">
          {[
            { title: "Embeddings", items: ["sentence-transformers", "OpenAI text-embedding-3", "Cohere embed-v3"] },
            { title: "Vector Store", items: ["FAISS", "ChromaDB", "pgvector"] },
            { title: "Re-ranking", items: ["Cross-Encoder", "GPT-4 / Claude", "Cohere Rerank"] },
          ].map((g) => (
            <div key={g.title} className="glass rounded-2xl p-5">
              <div className="text-xs uppercase tracking-wider text-muted-foreground mb-2">{g.title}</div>
              <ul className="space-y-1.5 text-sm">
                {g.items.map((it) => (
                  <li key={it} className="flex items-center gap-2">
                    <span className="size-1.5 rounded-full gradient-brand" />
                    {it}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </AppLayout>
  );
}
