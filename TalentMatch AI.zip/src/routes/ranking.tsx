import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { AppLayout } from "@/components/AppLayout";
import { AIPipelineModal } from "@/components/AIPipelineModal";
import { rankedCandidates } from "@/lib/mock-data";
import {
  Check, X, Download, FileSpreadsheet, FileText, Sparkles, Github, Linkedin,
  MapPin, GraduationCap, Trophy, Medal, Award,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { api } from "@/services/api";
import { toast } from "sonner";

export const Route = createFileRoute("/ranking")({
  head: () => ({ meta: [{ title: "AI Ranking — TalentAI" }] }),
  component: RankingPage,
});

function Bar({ label, value }: { label: string; value: number }) {
  return (
    <div>
      <div className="flex justify-between text-xs mb-1">
        <span className="text-muted-foreground">{label}</span>
        <span className="font-semibold">{value}%</span>
      </div>
      <div className="h-1.5 rounded-full bg-muted overflow-hidden">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${value}%` }}
          transition={{ duration: 0.9 }}
          className="h-full gradient-brand"
        />
      </div>
    </div>
  );
}

const rankIcons = [Trophy, Medal, Award];

function RankingPage() {
  const [showPipeline, setShowPipeline] = useState(false);
  const [ranked, setRanked] = useState(false);
  const [success, setSuccess] = useState(false);

  const runRanking = () => {
    setRanked(false);
    setShowPipeline(true);
  };

  const onComplete = async () => {
    await api.rankCandidates();
    setShowPipeline(false);
    setRanked(true);
    setSuccess(true);
    toast.success("AI ranking complete");
    setTimeout(() => setSuccess(false), 1800);
  };

  const onExport = async (fmt: "csv" | "excel" | "pdf") => {
    await api.exportRanking(fmt);
    toast.success(`Exported as ${fmt.toUpperCase()}`);
  };

  return (
    <AppLayout>
      <div className="space-y-6">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">AI Ranking</h1>
            <p className="text-muted-foreground mt-1">Semantic + skill + signal scoring with explanations.</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button variant="outline" onClick={() => onExport("csv")}><FileSpreadsheet className="size-4 mr-1.5" /> CSV</Button>
            <Button variant="outline" onClick={() => onExport("excel")}><FileText className="size-4 mr-1.5" /> Excel</Button>
            <Button variant="outline" onClick={() => onExport("pdf")}><Download className="size-4 mr-1.5" /> PDF</Button>
            <Button onClick={runRanking} className="gradient-brand text-white border-0 shadow-glow">
              <Sparkles className="size-4 mr-1.5" /> Generate Ranking
            </Button>
          </div>
        </div>

        <div className="glass rounded-2xl p-4 text-sm font-mono text-center">
          <span className="text-muted-foreground">Final Score =</span>{" "}
          <span className="text-gradient-brand font-bold">40% Semantic + 25% Skill + 15% Experience + 10% Behavioral + 10% Activity</span>
        </div>

        <AnimatePresence>
          {success && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="glass rounded-2xl p-4 flex items-center gap-3 border border-emerald-500/30"
            >
              <div className="size-9 rounded-full bg-emerald-500/20 grid place-items-center">
                <Check className="size-4 text-emerald-600 dark:text-emerald-300" />
              </div>
              <div className="text-sm">
                <div className="font-semibold">Ranking generated</div>
                <div className="text-muted-foreground">{rankedCandidates.length} candidates re-ranked by the LLM.</div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="grid lg:grid-cols-2 gap-4">
          {rankedCandidates.map((c, i) => {
            const RankIcon = rankIcons[i] ?? null;
            return (
              <motion.div
                key={c.id}
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.04 }}
                className="glass rounded-2xl p-6 hover:shadow-glow transition-shadow"
              >
                <div className="flex items-start gap-4">
                  <div className="relative">
                    <div className="size-14 rounded-full gradient-brand grid place-items-center text-white font-semibold shadow-glow">
                      {c.name.split(" ").map((n) => n[0]).join("")}
                    </div>
                    <div className="absolute -top-1 -left-1 size-6 rounded-full bg-background border border-border grid place-items-center text-[10px] font-bold">
                      {RankIcon ? <RankIcon className="size-3 text-primary" /> : `#${i + 1}`}
                    </div>
                  </div>
                  <div className="flex-1 min-w-0">
                    <Link to="/candidates/$id" params={{ id: c.id }} className="font-semibold hover:underline">
                      {c.name}
                    </Link>
                    <div className="text-xs text-muted-foreground">{c.title} • {c.experience}y</div>
                    <div className="flex flex-wrap gap-3 mt-1.5 text-[11px] text-muted-foreground">
                      <span className="inline-flex items-center gap-1"><MapPin className="size-3" />{c.location}</span>
                      <span className="inline-flex items-center gap-1"><GraduationCap className="size-3" />{c.education}</span>
                      <a href={`https://${c.github}`} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 hover:text-foreground"><Github className="size-3" />GitHub</a>
                      <a href={`https://${c.linkedin}`} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 hover:text-foreground"><Linkedin className="size-3" />LinkedIn</a>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-3xl font-bold text-gradient-brand">{c.final}</div>
                    <div className="text-[10px] uppercase tracking-wider text-muted-foreground">Final AI</div>
                    <div className="mt-1 text-[10px] font-medium text-emerald-600 dark:text-emerald-400">
                      {c.confidence}% confidence
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 mt-5">
                  <Bar label="Semantic Similarity" value={c.scores.semantic} />
                  <Bar label="Skill Match" value={c.scores.skill} />
                  <Bar label="Experience Match" value={c.scores.experience} />
                  <Bar label="Behavior Score" value={c.scores.behavioral} />
                  <Bar label="Platform Activity" value={c.scores.activity} />
                  <Bar label="Resume Score" value={Math.round((c.scores.skill + c.scores.experience) / 2)} />
                </div>

                {ranked && (
                  <motion.div
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="grid md:grid-cols-2 gap-3 mt-5"
                  >
                    <div className="rounded-xl p-3 bg-emerald-500/10">
                      <div className="text-xs font-semibold text-emerald-700 dark:text-emerald-300 mb-1.5 flex items-center gap-1">
                        <Check className="size-3.5" /> Why selected
                      </div>
                      <ul className="text-xs space-y-1 text-foreground/80">
                        {c.reasons.selected.slice(0, 4).map((r) => <li key={r}>✔ {r}</li>)}
                      </ul>
                    </div>
                    <div className="rounded-xl p-3 bg-rose-500/10">
                      <div className="text-xs font-semibold text-rose-700 dark:text-rose-300 mb-1.5 flex items-center gap-1">
                        <X className="size-3.5" /> Why not perfect
                      </div>
                      <ul className="text-xs space-y-1 text-foreground/80">
                        {c.reasons.missing.map((r) => <li key={r}>✖ {r}</li>)}
                      </ul>
                    </div>
                  </motion.div>
                )}
              </motion.div>
            );
          })}
        </div>
      </div>

      <AIPipelineModal open={showPipeline} onComplete={onComplete} onClose={() => setShowPipeline(false)} />
    </AppLayout>
  );
}
