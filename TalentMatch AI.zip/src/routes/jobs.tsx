import { createFileRoute } from "@tanstack/react-router";
import { useRef, useState } from "react";
import { motion } from "framer-motion";
import {
  Upload, Sparkles, GraduationCap, Briefcase, ListChecks, Wrench,
  Award, Building2, Heart, Star, FileText,
} from "lucide-react";
import { AppLayout } from "@/components/AppLayout";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { api, type JDAnalysis } from "@/services/api";
import { toast } from "sonner";

export const Route = createFileRoute("/jobs")({
  head: () => ({ meta: [{ title: "Job Intelligence — TalentAI" }] }),
  component: JobsPage,
});

function JobsPage() {
  const [jd, setJd] = useState("");
  const [analysis, setAnalysis] = useState<JDAnalysis | null>(null);
  const [loading, setLoading] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const analyze = async () => {
    if (!jd.trim()) return toast.error("Paste a job description or upload a file first");
    setLoading(true);
    setAnalysis(null);
    try {
      const result = await api.analyzeJD(jd);
      setAnalysis(result);
      toast.success("Job description analyzed");
    } finally {
      setLoading(false);
    }
  };

  const onUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const ok = /\.(pdf|docx|txt)$/i.test(file.name);
    if (!ok) return toast.error("Upload a PDF, DOCX, or TXT file");
    setLoading(true);
    try {
      await api.uploadJD(file);
      setJd(`[Imported from ${file.name}] — wire FastAPI to parse the file server-side.`);
      toast.success(`${file.name} uploaded`);
    } finally {
      setLoading(false);
    }
  };

  const cards = analysis
    ? [
        { icon: Wrench, title: "Required Skills", items: analysis.requiredSkills, tone: "chip" as const },
        { icon: Star, title: "Preferred Skills", items: analysis.preferredSkills, tone: "chip" as const },
        { icon: Briefcase, title: "Experience", items: [analysis.experience] },
        { icon: GraduationCap, title: "Education", items: [analysis.education] },
        { icon: Award, title: "Certifications", items: analysis.certifications },
        { icon: ListChecks, title: "Responsibilities", items: analysis.responsibilities },
        { icon: Building2, title: "Seniority & Industry", items: [analysis.seniority, analysis.industry] },
        { icon: Heart, title: "Soft Skills", items: analysis.softSkills, tone: "chip" as const },
      ]
    : [];

  return (
    <AppLayout>
      <div className="space-y-6 max-w-6xl">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Job Intelligence</h1>
          <p className="text-muted-foreground mt-1">
            Upload or paste a JD. AI extracts skills, seniority, soft skills, and more.
          </p>
        </div>

        <div className="glass rounded-2xl p-6">
          <Textarea
            value={jd}
            onChange={(e) => setJd(e.target.value)}
            placeholder="Paste the job description here..."
            className="min-h-48 resize-y bg-background/50"
          />
          <input
            ref={fileRef}
            type="file"
            accept=".pdf,.docx,.txt"
            className="hidden"
            onChange={onUpload}
          />
          <div className="mt-4 flex flex-wrap gap-2">
            <Button variant="outline" onClick={() => fileRef.current?.click()}>
              <Upload className="size-4 mr-1.5" /> Upload PDF / DOCX / TXT
            </Button>
            <Button
              onClick={analyze}
              disabled={loading}
              className="gradient-brand text-white border-0 shadow-glow ml-auto"
            >
              {loading ? (
                <><Sparkles className="size-4 mr-1.5 animate-pulse" /> Analyzing...</>
              ) : (
                <><Sparkles className="size-4 mr-1.5" /> Analyze JD</>
              )}
            </Button>
          </div>
        </div>

        {loading && (
          <div className="grid md:grid-cols-2 gap-4">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="glass rounded-2xl p-5">
                <Skeleton className="h-9 w-9 rounded-lg mb-3" />
                <Skeleton className="h-4 w-32 mb-3" />
                <Skeleton className="h-3 w-full mb-2" />
                <Skeleton className="h-3 w-2/3" />
              </div>
            ))}
          </div>
        )}

        {analysis && !loading && (
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} className="grid md:grid-cols-2 gap-4">
            {cards.map((c, i) => (
              <motion.div
                key={c.title}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
                className="glass rounded-2xl p-5"
              >
                <div className="flex items-center gap-2 mb-3">
                  <div className="size-9 rounded-lg gradient-brand grid place-items-center">
                    <c.icon className="size-4 text-white" />
                  </div>
                  <h3 className="font-semibold">{c.title}</h3>
                </div>
                {c.tone === "chip" ? (
                  <div className="flex flex-wrap gap-2">
                    {c.items.map((s) => (
                      <span key={s} className="px-2.5 py-1 text-xs rounded-full bg-accent text-accent-foreground font-medium">
                        {s}
                      </span>
                    ))}
                  </div>
                ) : (
                  <ul className="space-y-1.5 text-sm text-muted-foreground">
                    {c.items.map((it) => (
                      <li key={it} className="flex gap-2"><span className="text-primary">•</span>{it}</li>
                    ))}
                  </ul>
                )}
              </motion.div>
            ))}
          </motion.div>
        )}

        {!analysis && !loading && (
          <div className="glass rounded-2xl p-8 text-center text-sm text-muted-foreground">
            <FileText className="size-8 mx-auto mb-2 opacity-50" />
            Extracted entities will appear here after analysis.
          </div>
        )}
      </div>
    </AppLayout>
  );
}
