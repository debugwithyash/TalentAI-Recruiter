import { createFileRoute, Link } from "@tanstack/react-router";
import { useState, useMemo } from "react";
import {
  Upload, Search, FileSpreadsheet, FileJson, FileText, Github, Linkedin,
  SlidersHorizontal,
} from "lucide-react";
import { AppLayout } from "@/components/AppLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { candidates, finalScore } from "@/lib/mock-data";
import { toast } from "sonner";

export const Route = createFileRoute("/candidates/")({
  head: () => ({ meta: [{ title: "Candidates — TalentAI" }] }),
  component: CandidatesPage,
});

const statusColors: Record<string, string> = {
  New: "bg-blue-500/15 text-blue-600 dark:text-blue-300",
  Shortlisted: "bg-purple-500/15 text-purple-600 dark:text-purple-300",
  Interviewing: "bg-amber-500/15 text-amber-600 dark:text-amber-300",
  Rejected: "bg-rose-500/15 text-rose-600 dark:text-rose-300",
};

const allSkills = Array.from(new Set(candidates.flatMap((c) => c.skills))).sort();
const allLocations = Array.from(new Set(candidates.map((c) => c.location))).sort();
const allEducation = Array.from(new Set(candidates.map((c) => c.education))).sort();
const allModes = ["Remote", "Hybrid", "Onsite"] as const;
const allAvailability = ["Available", "Open", "Not looking"] as const;

function CandidatesPage() {
  const [q, setQ] = useState("");
  const [skills, setSkills] = useState<string[]>([]);
  const [location, setLocation] = useState("");
  const [education, setEducation] = useState("");
  const [mode, setMode] = useState("");
  const [availability, setAvailability] = useState("");
  const [minExp, setMinExp] = useState(0);
  const [minScore, setMinScore] = useState(0);

  const filtered = useMemo(
    () =>
      candidates.filter((c) => {
        const score = finalScore(c);
        const matchesQ = [c.name, c.title, ...c.skills].join(" ").toLowerCase().includes(q.toLowerCase());
        const matchesSkills = skills.length === 0 || skills.every((s) => c.skills.includes(s));
        const matchesLoc = !location || c.location === location;
        const matchesEdu = !education || c.education === education;
        const matchesMode = !mode || c.workMode === mode;
        const matchesAvail = !availability || c.availability === availability;
        return (
          matchesQ && matchesSkills && matchesLoc && matchesEdu && matchesMode &&
          matchesAvail && c.experience >= minExp && score >= minScore
        );
      }),
    [q, skills, location, education, mode, availability, minExp, minScore]
  );

  const toggleSkill = (s: string) =>
    setSkills((prev) => (prev.includes(s) ? prev.filter((x) => x !== s) : [...prev, s]));

  return (
    <AppLayout>
      <div className="space-y-6">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Candidates</h1>
            <p className="text-muted-foreground mt-1">{filtered.length} candidates in your pool</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => toast("CSV export ready — wire FastAPI to enable")}><FileSpreadsheet className="size-4 mr-1.5" /> CSV</Button>
            <Button variant="outline" onClick={() => toast("JSON export ready")}><FileJson className="size-4 mr-1.5" /> JSON</Button>
            <Button variant="outline" onClick={() => toast("Excel export ready")}><FileText className="size-4 mr-1.5" /> Excel</Button>
            <Button className="gradient-brand text-white border-0 shadow-glow"><Upload className="size-4 mr-1.5" /> Upload</Button>
          </div>
        </div>

        <div className="grid lg:grid-cols-[280px_1fr] gap-4">
          {/* Filters */}
          <aside className="glass rounded-2xl p-5 space-y-5 h-fit">
            <div className="flex items-center gap-2">
              <SlidersHorizontal className="size-4 text-primary" />
              <h3 className="font-semibold">Filters</h3>
            </div>

            <div>
              <label className="text-xs font-medium uppercase tracking-wider text-muted-foreground">Skills</label>
              <div className="flex flex-wrap gap-1.5 mt-2 max-h-32 overflow-y-auto">
                {allSkills.map((s) => (
                  <button
                    key={s}
                    onClick={() => toggleSkill(s)}
                    className={`text-[11px] px-2 py-0.5 rounded-full border transition ${
                      skills.includes(s)
                        ? "gradient-brand text-white border-transparent shadow-glow"
                        : "border-border hover:border-primary/50"
                    }`}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>

            <Select label="Location" value={location} onChange={setLocation} options={allLocations} />
            <Select label="Education" value={education} onChange={setEducation} options={allEducation} />
            <Select label="Availability" value={availability} onChange={setAvailability} options={[...allAvailability]} />
            <Select label="Work Mode" value={mode} onChange={setMode} options={[...allModes]} />

            <div>
              <label className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                Min. Experience: {minExp}y
              </label>
              <Slider value={[minExp]} onValueChange={([v]) => setMinExp(v)} min={0} max={12} step={1} className="mt-3" />
            </div>

            <div>
              <label className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                Min. AI Score: {minScore}
              </label>
              <Slider value={[minScore]} onValueChange={([v]) => setMinScore(v)} min={0} max={100} step={5} className="mt-3" />
            </div>

            <Button
              variant="outline"
              className="w-full"
              onClick={() => {
                setSkills([]); setLocation(""); setEducation(""); setMode("");
                setAvailability(""); setMinExp(0); setMinScore(0); setQ("");
              }}
            >
              Reset filters
            </Button>
          </aside>

          {/* Table */}
          <div className="glass rounded-2xl p-2">
            <div className="p-3">
              <div className="relative max-w-md">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
                <Input
                  value={q}
                  onChange={(e) => setQ(e.target.value)}
                  placeholder="Search by name, role, skill..."
                  className="pl-9 bg-background/50"
                />
              </div>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="text-xs uppercase tracking-wider text-muted-foreground border-y border-border">
                  <tr>
                    <th className="text-left font-medium px-4 py-3">Name</th>
                    <th className="text-left font-medium px-4 py-3">Exp</th>
                    <th className="text-left font-medium px-4 py-3">Skills</th>
                    <th className="text-left font-medium px-4 py-3">Mode</th>
                    <th className="text-left font-medium px-4 py-3">Score</th>
                    <th className="text-left font-medium px-4 py-3">Links</th>
                    <th className="text-left font-medium px-4 py-3">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((c) => (
                    <tr key={c.id} className="border-b border-border last:border-0 hover:bg-muted/40 transition">
                      <td className="px-4 py-3">
                        <Link to="/candidates/$id" params={{ id: c.id }} className="flex items-center gap-3">
                          <div className="size-9 rounded-full gradient-brand grid place-items-center text-white text-xs font-semibold">
                            {c.name.split(" ").map((n) => n[0]).join("")}
                          </div>
                          <div>
                            <div className="font-medium">{c.name}</div>
                            <div className="text-xs text-muted-foreground">{c.title} • {c.location}</div>
                          </div>
                        </Link>
                      </td>
                      <td className="px-4 py-3">{c.experience}y</td>
                      <td className="px-4 py-3">
                        <div className="flex gap-1 flex-wrap max-w-xs">
                          {c.skills.slice(0, 3).map((s) => (
                            <span key={s} className="text-[10px] px-2 py-0.5 rounded-full bg-accent text-accent-foreground">{s}</span>
                          ))}
                          {c.skills.length > 3 && <span className="text-[10px] text-muted-foreground">+{c.skills.length - 3}</span>}
                        </div>
                      </td>
                      <td className="px-4 py-3 text-xs text-muted-foreground">{c.workMode}</td>
                      <td className="px-4 py-3 font-semibold text-gradient-brand">{finalScore(c)}</td>
                      <td className="px-4 py-3">
                        <div className="flex gap-2 text-muted-foreground">
                          <a href={`https://${c.github}`} target="_blank" rel="noreferrer"><Github className="size-4 hover:text-foreground" /></a>
                          <a href={`https://${c.linkedin}`} target="_blank" rel="noreferrer"><Linkedin className="size-4 hover:text-foreground" /></a>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${statusColors[c.status]}`}>
                          {c.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                  {filtered.length === 0 && (
                    <tr><td colSpan={7} className="text-center py-10 text-muted-foreground text-sm">No candidates match your filters.</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}

function Select({
  label, value, onChange, options,
}: { label: string; value: string; onChange: (v: string) => void; options: string[] }) {
  return (
    <div>
      <label className="text-xs font-medium uppercase tracking-wider text-muted-foreground">{label}</label>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full mt-2 rounded-lg border border-border bg-background/50 px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary/30"
      >
        <option value="">Any</option>
        {options.map((o) => <option key={o} value={o}>{o}</option>)}
      </select>
    </div>
  );
}
