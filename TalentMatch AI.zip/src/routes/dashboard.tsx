import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { Users, FileText, Sparkles, TrendingUp, ArrowRight } from "lucide-react";
import { AppLayout } from "@/components/AppLayout";
import { rankedCandidates, funnelData } from "@/lib/mock-data";
import {
  ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, BarChart, Bar, CartesianGrid,
} from "recharts";

export const Route = createFileRoute("/dashboard")({
  head: () => ({ meta: [{ title: "Dashboard — TalentAI" }] }),
  component: Dashboard,
});

const stats = [
  { label: "Total Candidates", value: "1,284", icon: Users, change: "+12%" },
  { label: "Uploaded Jobs", value: "27", icon: FileText, change: "+3" },
  { label: "AI Matches", value: "362", icon: Sparkles, change: "+48" },
  { label: "Avg Match Score", value: "82.4", icon: TrendingUp, change: "+2.1" },
];

const trend = Array.from({ length: 14 }, (_, i) => ({
  day: `D${i + 1}`,
  matches: Math.round(20 + Math.random() * 40 + i * 2),
}));

function Dashboard() {
  return (
    <AppLayout>
      <div className="space-y-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Welcome back, Rachel</h1>
          <p className="text-muted-foreground mt-1">Here's what's happening in your hiring pipeline.</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {stats.map((s, i) => (
            <motion.div
              key={s.label}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: i * 0.05 }}
              className="glass rounded-2xl p-5 shadow-soft"
            >
              <div className="flex items-center justify-between">
                <div className="size-10 rounded-xl gradient-brand grid place-items-center shadow-glow">
                  <s.icon className="size-5 text-white" />
                </div>
                <span className="text-xs font-medium text-primary">{s.change}</span>
              </div>
              <div className="mt-4 text-3xl font-bold tracking-tight">{s.value}</div>
              <div className="text-sm text-muted-foreground">{s.label}</div>
            </motion.div>
          ))}
        </div>

        <div className="grid lg:grid-cols-3 gap-4">
          <div className="lg:col-span-2 glass rounded-2xl p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="font-semibold">AI matches over time</h3>
                <p className="text-xs text-muted-foreground">Last 14 days</p>
              </div>
            </div>
            <div className="h-64">
              <ResponsiveContainer>
                <AreaChart data={trend}>
                  <defs>
                    <linearGradient id="g1" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="var(--brand)" stopOpacity={0.5} />
                      <stop offset="100%" stopColor="var(--brand)" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                  <XAxis dataKey="day" stroke="var(--muted-foreground)" fontSize={11} />
                  <YAxis stroke="var(--muted-foreground)" fontSize={11} />
                  <Tooltip
                    contentStyle={{ background: "var(--popover)", border: "1px solid var(--border)", borderRadius: 12 }}
                  />
                  <Area type="monotone" dataKey="matches" stroke="var(--brand)" strokeWidth={2} fill="url(#g1)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="glass rounded-2xl p-6">
            <h3 className="font-semibold mb-4">Hiring funnel</h3>
            <div className="h-64">
              <ResponsiveContainer>
                <BarChart data={funnelData} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                  <XAxis type="number" stroke="var(--muted-foreground)" fontSize={11} />
                  <YAxis type="category" dataKey="stage" stroke="var(--muted-foreground)" fontSize={11} width={70} />
                  <Tooltip contentStyle={{ background: "var(--popover)", border: "1px solid var(--border)", borderRadius: 12 }} />
                  <Bar dataKey="value" fill="var(--brand)" radius={[0, 8, 8, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        <div className="glass rounded-2xl p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold">Top ranked candidates</h3>
            <Link to="/ranking" className="text-sm text-primary inline-flex items-center gap-1">
              View all <ArrowRight className="size-3.5" />
            </Link>
          </div>
          <div className="space-y-2">
            {rankedCandidates.slice(0, 5).map((c) => (
              <div key={c.id} className="flex items-center gap-4 p-3 rounded-xl hover:bg-muted/50 transition">
                <div className="size-10 rounded-full gradient-brand grid place-items-center text-white text-sm font-semibold">
                  {c.name.split(" ").map((n) => n[0]).join("")}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="font-medium truncate">{c.name}</div>
                  <div className="text-xs text-muted-foreground truncate">{c.title} • {c.location}</div>
                </div>
                <div className="hidden md:flex gap-1">
                  {c.skills.slice(0, 3).map((s) => (
                    <span key={s} className="text-[10px] px-2 py-0.5 rounded-full bg-accent text-accent-foreground">{s}</span>
                  ))}
                </div>
                <div className="w-28 h-2 rounded-full bg-muted overflow-hidden">
                  <div className="h-full gradient-brand" style={{ width: `${c.final}%` }} />
                </div>
                <div className="text-sm font-bold w-10 text-right">{c.final}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
