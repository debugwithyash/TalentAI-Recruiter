import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { AppLayout } from "@/components/AppLayout";
import { candidates, finalScore, type Candidate } from "@/lib/mock-data";
import {
  ArrowLeft, Github, Linkedin, MapPin, Mail, Calendar, FileText,
  Check, X, Sparkles, ThumbsUp,
} from "lucide-react";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/candidates/$id")({
  head: () => ({ meta: [{ title: "Candidate — TalentAI" }] }),
  component: CandidateDetail,
  notFoundComponent: () => (
    <AppLayout>
      <div className="text-center py-20 text-muted-foreground">Candidate not found</div>
    </AppLayout>
  ),
  errorComponent: () => (
    <AppLayout>
      <div className="text-center py-20 text-muted-foreground">Could not load this candidate.</div>
    </AppLayout>
  ),
  loader: ({ params }) => {
    const c = candidates.find((x) => x.id === params.id);
    if (!c) throw notFound();
    return c;
  },
});

const recColors: Record<Candidate["recommendation"], string> = {
  "Strong Hire": "bg-emerald-500/15 text-emerald-600 dark:text-emerald-300 border-emerald-500/30",
  "Hire": "bg-blue-500/15 text-blue-600 dark:text-blue-300 border-blue-500/30",
  "Maybe": "bg-amber-500/15 text-amber-600 dark:text-amber-300 border-amber-500/30",
  "Pass": "bg-rose-500/15 text-rose-600 dark:text-rose-300 border-rose-500/30",
};

function CandidateDetail() {
  const c = Route.useLoaderData() as Candidate;
  const score = finalScore(c);

  return (
    <AppLayout>
      <div className="space-y-6 max-w-5xl">
        <Link to="/candidates" className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground">
          <ArrowLeft className="size-4" /> Back to candidates
        </Link>

        <div className="glass rounded-3xl p-8">
          <div className="flex flex-col md:flex-row gap-6 items-start">
            <div className="size-24 rounded-2xl gradient-brand grid place-items-center text-white text-2xl font-bold shadow-glow">
              {c.name.split(" ").map((n) => n[0]).join("")}
            </div>
            <div className="flex-1">
              <div className="flex flex-wrap items-center gap-3">
                <h1 className="text-3xl font-bold tracking-tight">{c.name}</h1>
                <span className={`text-xs px-2.5 py-1 rounded-full font-semibold border ${recColors[c.recommendation]}`}>
                  {c.recommendation}
                </span>
              </div>
              <p className="text-muted-foreground">{c.title}</p>
              <div className="flex flex-wrap gap-4 mt-3 text-sm text-muted-foreground">
                <span className="inline-flex items-center gap-1"><MapPin className="size-3.5" />{c.location}</span>
                <span>{c.workMode}</span>
                <span>{c.availability}</span>
                <a href={`https://${c.github}`} className="inline-flex items-center gap-1 hover:text-foreground" target="_blank" rel="noreferrer"><Github className="size-3.5" />GitHub</a>
                <a href={`https://${c.linkedin}`} className="inline-flex items-center gap-1 hover:text-foreground" target="_blank" rel="noreferrer"><Linkedin className="size-3.5" />LinkedIn</a>
              </div>
              <div className="flex gap-2 mt-4">
                <Button className="gradient-brand text-white border-0"><Mail className="size-4 mr-1.5" /> Email candidate</Button>
                <Button variant="outline"><Calendar className="size-4 mr-1.5" /> Schedule interview</Button>
              </div>
            </div>
            <div className="text-center">
              <div className="text-5xl font-bold text-gradient-brand">{score}</div>
              <div className="text-xs uppercase tracking-wider text-muted-foreground">AI Score</div>
              <div className="text-xs text-emerald-600 dark:text-emerald-400 mt-1 font-medium">{c.confidence}% confidence</div>
            </div>
          </div>
        </div>

        {/* AI Summary */}
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="glass rounded-2xl p-6 border border-primary/20">
          <div className="flex items-center gap-2 mb-3">
            <div className="size-9 rounded-lg gradient-brand grid place-items-center shadow-glow">
              <Sparkles className="size-4 text-white" />
            </div>
            <h3 className="font-semibold">AI Summary</h3>
          </div>
          <p className="text-sm text-foreground/80 leading-relaxed">{c.aiSummary}</p>

          <div className="grid md:grid-cols-2 gap-3 mt-4">
            <div className="rounded-xl p-3 bg-emerald-500/10">
              <div className="text-xs font-semibold text-emerald-700 dark:text-emerald-300 mb-1.5 flex items-center gap-1">
                <Check className="size-3.5" /> Strengths
              </div>
              <ul className="text-xs space-y-1 text-foreground/80">
                {c.strengths.map((s) => <li key={s}>✔ {s}</li>)}
              </ul>
            </div>
            <div className="rounded-xl p-3 bg-rose-500/10">
              <div className="text-xs font-semibold text-rose-700 dark:text-rose-300 mb-1.5 flex items-center gap-1">
                <X className="size-3.5" /> Weaknesses
              </div>
              <ul className="text-xs space-y-1 text-foreground/80">
                {c.weaknesses.map((s) => <li key={s}>✖ {s}</li>)}
              </ul>
            </div>
          </div>

          <div className="mt-4 rounded-xl bg-background/50 border border-border p-3 text-sm flex items-start gap-2">
            <ThumbsUp className="size-4 text-primary mt-0.5" />
            <div>
              <span className="font-semibold">Hiring Recommendation: </span>
              <span className="text-foreground/80">{c.recommendation} — based on weighted signals and LLM re-ranking.</span>
            </div>
          </div>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-4">
          <div className="md:col-span-2 space-y-4">
            <Section title="Timeline">
              <ol className="relative border-l-2 border-border ml-2 space-y-4 pl-5">
                {c.timeline.map((t) => (
                  <li key={t.event} className="relative">
                    <span className="absolute -left-[27px] size-3 rounded-full gradient-brand top-1.5" />
                    <div className="text-xs text-muted-foreground">{t.date}</div>
                    <div className="font-medium">{t.event}</div>
                  </li>
                ))}
              </ol>
            </Section>

            <Section title="Projects & Portfolio">
              <div className="space-y-3">
                {c.projects.map((p) => (
                  <div key={p.name} className="p-3 rounded-xl bg-muted/40">
                    <div className="font-medium">{p.name}</div>
                    <div className="text-sm text-muted-foreground">{p.description}</div>
                  </div>
                ))}
              </div>
            </Section>

            <Section title="Resume preview">
              <div className="aspect-[8.5/11] max-w-xs rounded-xl border border-dashed border-border grid place-items-center text-muted-foreground bg-muted/20">
                <div className="text-center">
                  <FileText className="size-8 mx-auto mb-2" />
                  <div className="text-sm">resume_{c.name.split(" ")[0].toLowerCase()}.pdf</div>
                </div>
              </div>
            </Section>
          </div>

          <div className="space-y-4">
            <Section title="Skills">
              <div className="flex flex-wrap gap-2">
                {c.skills.map((s) => (
                  <span key={s} className="px-2.5 py-1 text-xs rounded-full bg-accent text-accent-foreground font-medium">{s}</span>
                ))}
              </div>
            </Section>
            <Section title="Education">
              <div className="text-sm">{c.education}</div>
            </Section>
            <Section title="Certifications">
              <ul className="text-sm space-y-1">
                {c.certifications.map((cert) => <li key={cert}>• {cert}</li>)}
              </ul>
            </Section>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="glass rounded-2xl p-5">
      <h3 className="font-semibold mb-3">{title}</h3>
      {children}
    </div>
  );
}
