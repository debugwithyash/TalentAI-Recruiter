import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { Brain, Sparkles, Target, Zap, BarChart3, ArrowRight, FileText, Users, Trophy } from "lucide-react";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "TalentAI Recruiter — AI-Powered Candidate Ranking" },
      { name: "description", content: "Semantic candidate ranking with explainable AI. Hire smarter, not harder." },
    ],
  }),
  component: Landing,
});

function Landing() {
  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      {/* Nav */}
      <nav className="sticky top-0 z-50 backdrop-blur-xl bg-background/70 border-b border-border">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <div className="size-9 rounded-xl gradient-brand grid place-items-center shadow-glow">
              <Brain className="size-5 text-white" />
            </div>
            <span className="font-bold text-lg tracking-tight">TalentAI</span>
          </Link>
          <div className="hidden md:flex items-center gap-8 text-sm">
            <a href="#features" className="text-muted-foreground hover:text-foreground">Features</a>
            <a href="#how" className="text-muted-foreground hover:text-foreground">How it works</a>
            <a href="#pipeline" className="text-muted-foreground hover:text-foreground">AI Pipeline</a>
          </div>
          <Button asChild className="gradient-brand text-white shadow-glow border-0">
            <Link to="/dashboard">Open App <ArrowRight className="size-4 ml-1" /></Link>
          </Button>
        </div>
      </nav>

      {/* Hero */}
      <section className="relative gradient-hero">
        <div className="max-w-7xl mx-auto px-6 pt-20 pb-32 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="inline-flex items-center gap-2 glass px-4 py-1.5 rounded-full text-sm mb-8"
          >
            <Sparkles className="size-3.5 text-primary" />
            <span>Semantic ranking, not keyword matching</span>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.1 }}
            className="text-5xl md:text-7xl font-bold tracking-tight leading-[1.05] max-w-4xl mx-auto"
          >
            Hire the right people with{" "}
            <span className="text-gradient-brand">explainable AI</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="mt-6 text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto"
          >
            TalentAI reads your job description, understands intent, and ranks candidates by
            semantic fit — with transparent reasons for every decision.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.3 }}
            className="mt-10 flex flex-wrap gap-3 justify-center"
          >
            <Button size="lg" asChild className="gradient-brand text-white shadow-glow border-0 h-12 px-6">
              <Link to="/dashboard">Try the dashboard <ArrowRight className="size-4 ml-1.5" /></Link>
            </Button>
            <Button size="lg" variant="outline" asChild className="h-12 px-6 glass">
              <a href="#pipeline">See the AI pipeline</a>
            </Button>
          </motion.div>

          {/* Floating preview card */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.4 }}
            className="mt-20 mx-auto max-w-4xl glass rounded-3xl p-2 shadow-glow"
          >
            <div className="rounded-2xl bg-card p-6 text-left">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2 text-sm font-medium">
                  <Trophy className="size-4 text-primary" />
                  Top candidate match
                </div>
                <div className="text-xs text-muted-foreground">Real-time ranking</div>
              </div>
              {[
                { name: "Aisha Khan", score: 96, role: "Senior ML Engineer" },
                { name: "Marcus Chen", score: 91, role: "AI Research Engineer" },
                { name: "Priya Patel", score: 87, role: "Full-Stack Developer" },
              ].map((c, i) => (
                <div key={c.name} className="flex items-center gap-4 py-3 border-t border-border first:border-0">
                  <div className="size-10 rounded-full gradient-brand grid place-items-center text-white font-semibold text-sm">
                    {c.name.split(" ").map((s) => s[0]).join("")}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-medium truncate">{c.name}</div>
                    <div className="text-xs text-muted-foreground truncate">{c.role}</div>
                  </div>
                  <div className="w-32 h-2 rounded-full bg-muted overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${c.score}%` }}
                      transition={{ duration: 1, delay: 0.6 + i * 0.15 }}
                      className="h-full gradient-brand"
                    />
                  </div>
                  <div className="text-sm font-bold w-10 text-right">{c.score}</div>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="py-24 max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold tracking-tight">Built for modern hiring teams</h2>
          <p className="mt-3 text-muted-foreground">Everything you need to find the right candidate, fast.</p>
        </div>
        <div className="grid md:grid-cols-3 gap-6">
          {[
            { icon: Target, title: "Semantic matching", desc: "Vector embeddings understand intent — not just keywords." },
            { icon: Sparkles, title: "Explainable AI", desc: "Every score comes with reasons selected and gaps identified." },
            { icon: Zap, title: "Instant ranking", desc: "Re-rank thousands of candidates in seconds with LLM scoring." },
            { icon: FileText, title: "Smart JD parsing", desc: "Extract skills, experience and responsibilities automatically." },
            { icon: Users, title: "Bulk imports", desc: "Upload CSV, JSON, Excel — we normalize and dedupe." },
            { icon: BarChart3, title: "Analytics built-in", desc: "Hiring funnel, skill distribution, top sources at a glance." },
          ].map((f, i) => (
            <motion.div
              key={f.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.05 }}
              className="glass rounded-2xl p-6 hover:shadow-glow transition-shadow"
            >
              <div className="size-11 rounded-xl gradient-brand grid place-items-center mb-4 shadow-glow">
                <f.icon className="size-5 text-white" />
              </div>
              <h3 className="font-semibold text-lg">{f.title}</h3>
              <p className="text-sm text-muted-foreground mt-1.5">{f.desc}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* How it works */}
      <section id="how" className="py-24 gradient-soft">
        <div className="max-w-5xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold tracking-tight">How it works</h2>
          </div>
          <div className="grid md:grid-cols-4 gap-6">
            {[
              { step: "01", title: "Paste JD", desc: "Drop in a job description or upload a PDF." },
              { step: "02", title: "Upload candidates", desc: "CSV, JSON, or Excel — we handle the rest." },
              { step: "03", title: "AI ranks", desc: "Semantic search + LLM re-ranking finds the best fits." },
              { step: "04", title: "Explain & export", desc: "See reasons, shortlist, export to your ATS." },
            ].map((s) => (
              <div key={s.step} className="glass rounded-2xl p-6">
                <div className="text-gradient-brand text-3xl font-bold">{s.step}</div>
                <div className="font-semibold mt-2">{s.title}</div>
                <div className="text-sm text-muted-foreground mt-1">{s.desc}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* AI Pipeline */}
      <section id="pipeline" className="py-24 max-w-5xl mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold tracking-tight">The AI pipeline</h2>
          <p className="mt-3 text-muted-foreground">Transparent end-to-end ranking architecture.</p>
        </div>
        <div className="glass rounded-3xl p-8 md:p-12">
          <div className="flex flex-col items-center gap-3">
            {[
              "Job Description",
              "Requirement Extraction",
              "Sentence Embeddings",
              "Vector Database",
              "Semantic Search",
              "Candidate Ranking",
              "LLM Re-ranking",
              "Final Shortlist",
            ].map((step, i, arr) => (
              <div key={step} className="w-full max-w-sm">
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.4, delay: i * 0.06 }}
                  className="rounded-xl px-5 py-3 text-center font-medium border border-border bg-card"
                >
                  {step}
                </motion.div>
                {i < arr.length - 1 && (
                  <div className="h-6 w-px bg-gradient-to-b from-primary/60 to-transparent mx-auto" />
                )}
              </div>
            ))}
          </div>

          <div className="mt-10 p-5 rounded-2xl gradient-brand text-white">
            <div className="text-xs uppercase opacity-80 tracking-wider">Final ranking formula</div>
            <div className="font-mono text-sm md:text-base mt-2">
              Final = 40% Semantic + 25% Skill + 15% Experience + 10% Behavioral + 10% Activity
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 px-6">
        <div className="max-w-4xl mx-auto glass rounded-3xl p-12 text-center shadow-glow">
          <h2 className="text-4xl font-bold tracking-tight">Start ranking smarter today</h2>
          <p className="mt-3 text-muted-foreground">Free to explore. No credit card required.</p>
          <Button size="lg" asChild className="mt-8 gradient-brand text-white h-12 px-8 border-0">
            <Link to="/dashboard">Launch dashboard <ArrowRight className="size-4 ml-1.5" /></Link>
          </Button>
        </div>
      </section>

      <footer className="border-t border-border py-8 text-center text-sm text-muted-foreground">
        © 2026 TalentAI Recruiter. Built with semantic intelligence.
      </footer>
    </div>
  );
}
